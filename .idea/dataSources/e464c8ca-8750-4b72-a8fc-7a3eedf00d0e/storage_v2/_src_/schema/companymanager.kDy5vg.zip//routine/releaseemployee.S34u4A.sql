create procedure releaseEmployee(IN workerID char(11))
  BEGIN
    UPDATE Workers SET endDate=curdate() WHERE person=workerID;
END;

