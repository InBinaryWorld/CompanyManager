create procedure makeTransfer(IN professionI varchar(60))
  BEGIN
	DECLARE peselC CHAR(11);
    DECLARE salaryC FLOAT;
    DECLARE budget int;
    DECLARE transactionId INT;
	DECLARE cursor_done BOOLEAN DEFAULT FALSE;
    DECLARE cursorC CURSOR FOR SELECT person,salary FROM Workers WHERE profession = professionI;  
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET cursor_done = TRUE;
	SET autocommit = 0;
    SET budget = (SELECT currentState From portfolio ORDER BY id DESC LIMIT 1);
    OPEN cursorC;
	START TRANSACTION;
    INSERT INTO portfolio VALUES (NULL,0,budget,curdate(),concat('Salary for ',professionI));
	SET transactionId = (SELECT id From portfolio ORDER BY id DESC LIMIT 1);
    read_loop: LOOP
		FETCH  cursorC INTO peselC,salaryC;
        SET budget = budget - salaryC;
		IF cursor_done OR budget < 0 THEN
			CLOSE cursorC;
			LEAVE read_loop;
		END IF;
        UPDATE portfolio SET `change`= `change`- salaryC, currentState = currentState - salaryC WHERE id=transactionId;
        INSERT INTO transfersMade VALUES(NULL,transactionId,peselC,salaryC);
	END LOOP;
    IF budget < 0 THEN
		ROLLBACK;
	ELSE
		COMMIT;
	END IF;
    SET autocommit = 1;
END;

