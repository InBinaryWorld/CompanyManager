create trigger workers_U
  before UPDATE
  on workers
  for each row
  BEGIN

     IF new.endDate IS NOT NULL AND timestampdiff(day,new.beginDate,new.endDate)< 0 THEN
    set @msg = "Wrong date";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
    IF new.salary < 0 THEN
    set @msg = "Wrong salary";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
    IF timestampdiff(day,(SELECT dateOfBirth FROM Persons WHERE pesel = new.person),new.beginDate) < 18 THEN
    set @msg = "Person is underage";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
END;

