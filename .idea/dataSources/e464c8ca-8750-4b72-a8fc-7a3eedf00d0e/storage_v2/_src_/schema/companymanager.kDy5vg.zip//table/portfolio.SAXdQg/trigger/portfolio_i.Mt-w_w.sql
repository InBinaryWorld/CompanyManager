create trigger portfolio_I
  before INSERT
  on portfolio
  for each row
  BEGIN
    IF new.currentState < 0 THEN
    set @msg = "Wrong salary";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
END;

