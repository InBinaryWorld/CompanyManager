create trigger leaves_I
  before INSERT
  on leaves
  for each row
  BEGIN
    IF timestampdiff(day,new.beginDate,new.endDate) < 0 THEN
    set @msg = "Wrong date";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
    IF (SELECT sum(days) FROM(SELECT timestampdiff(day,beginDate,endDate)+1 AS days 
		FROM Leaves WHERE Leaves.worker = new.worker)A)+timestampdiff(day,new.beginDate,new.endDate)+1 
		> (SELECT sum(months)*26/12 FROM (SELECT timestampdiff(month,beginDate,IFNULL(endDate,curdate())) AS months 
        FROM Workers WHERE Workers.person = new.worker )A) THEN
    set @msg = "Can not take a leave";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
    END IF;
END;

