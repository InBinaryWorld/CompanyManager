create trigger transfersMade_I
  before INSERT
  on transfersmade
  for each row
  BEGIN
    IF new.amount <= 0 THEN
    set @msg = "Wrong amount";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
END;

