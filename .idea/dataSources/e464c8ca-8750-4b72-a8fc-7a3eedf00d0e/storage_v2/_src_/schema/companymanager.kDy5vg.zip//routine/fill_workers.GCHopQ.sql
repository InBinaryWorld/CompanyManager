create procedure fill_Workers()
  BEGIN

	DECLARE i INT;
    DECLARE peselC char(11);
	DECLARE cursor_done BOOLEAN DEFAULT FALSE;
    DECLARE cursorC CURSOR FOR SELECT pesel FROM Persons ORDER BY RAND();  
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET cursor_done = TRUE;
    OPEN cursorC;
	IF cursor_done THEN    	
		CLOSE cursorC;
	END IF;
    
	SET i = 0;
	WHILE i < 50 DO
		SET i = i + 1;
		FETCH  cursorC INTO peselC;
		INSERT INTO Workers VALUES (
        NULL,
        peselC,
        'AKTOR',
        FLOOR(RAND()*(9001)+1000),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)+11) year),interval FLOOR(RAND()*(365)) day),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)) year),interval FLOOR(RAND()*(365)) day));
	END WHILE;
    
    SET i = 0;
	WHILE i < 33 DO
		SET i = i + 1;
		FETCH  cursorC INTO peselC;
		INSERT INTO Workers VALUES (
        NULL,
        peselC,
        'AGENT',
        FLOOR(RAND()*(4001)+1000),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)+11) year),interval FLOOR(RAND()*(365)) day),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)) year),interval FLOOR(RAND()*(365)) day));
	END WHILE;
    
    SET i = 0;
	WHILE i < 13 DO
		SET i = i + 1;
		FETCH  cursorC INTO peselC;
		INSERT INTO Workers VALUES (
        NULL,
        peselC,
        'INFORMATYK',
        FLOOR(RAND()*(10001)+5000),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)+11) year),interval FLOOR(RAND()*(365)) day),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)) year),interval FLOOR(RAND()*(365)) day));
	END WHILE;
    
    SET i = 0;
	WHILE i < 2 DO
		SET i = i + 1;
		FETCH  cursorC INTO peselC;
		INSERT INTO Workers VALUES (
        NULL,
        peselC,
        'REPORTER',
        FLOOR(RAND()*(8001)+2000),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)+11) year),interval FLOOR(RAND()*(365)) day),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)) year),interval FLOOR(RAND()*(365)) day));
	END WHILE;
    
    SET i = 0;
	WHILE i < 77 DO
		SET i = i + 1;
		FETCH  cursorC INTO peselC;
		INSERT INTO Workers VALUES (
        NULL,
        peselC,
        'SPRZEDAWCA',
        FLOOR(RAND()*(4001)+2000),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)+11) year),interval FLOOR(RAND()*(365)) day),
        date_add(date_add(curdate(),interval -FLOOR(RAND()*(10)) year),interval FLOOR(RAND()*(365)) day));
	END WHILE;
    
    CLOSE cursorC;
END;

