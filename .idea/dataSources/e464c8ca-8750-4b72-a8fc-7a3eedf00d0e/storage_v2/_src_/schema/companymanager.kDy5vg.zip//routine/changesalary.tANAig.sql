create procedure changeSalary(IN workerID char(11), IN newSalary int)
  BEGIN
	SET autocommit = 0;
	START TRANSACTION;
    INSERT INTO salaryHistory VALUES(NULL,(SELECT salary FROM workers WHERE person = workerID ),newSalary,workerID,curdate());
    UPDATE Workers SET salary=newSalary WHERE person=workerID;
	COMMIT;
    SET autocommit = 1;
END;

