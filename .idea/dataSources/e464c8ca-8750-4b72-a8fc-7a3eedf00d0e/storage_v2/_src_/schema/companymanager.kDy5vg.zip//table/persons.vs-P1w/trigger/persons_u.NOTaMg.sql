create trigger persons_U
  before UPDATE
  on persons
  for each row
  BEGIN
	IF new.pesel NOT REGEXP '^[0-9]+$' OR char_length(new.pesel) != 11 THEN
		set @msg = "Wrong PESEL";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
    IF new.name NOT REGEXP '^[a-zA-Z.]+$' THEN
		set @msg = "Wrong Name";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
    IF new.surname NOT REGEXP '^[a-zA-Z.]+$' THEN
		set @msg = "Wrong Surname";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
     IF timestampdiff(day,new.dateOfBirth,curdate()) < 0 THEN
    set @msg = "Wrong date of birth";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
END;

