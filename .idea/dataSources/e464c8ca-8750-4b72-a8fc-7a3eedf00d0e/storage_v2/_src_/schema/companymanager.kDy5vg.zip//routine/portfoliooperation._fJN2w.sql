create procedure portfolioOperation(IN changeI int, IN title varchar(100))
  BEGIN
	DECLARE budget INT;
    SET budget =(SELECT currentState From portfolio ORDER BY id DESC LIMIT 1);
    INSERT INTO portfolio VALUES(NULL,changeI,budget+changeI,curdate(),title);
END;

