create trigger portfolio_U
  before UPDATE
  on portfolio
  for each row
  BEGIN
    IF new.currentState < 0 THEN
    set @msg = "Insufficient funds on the account";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
END;

