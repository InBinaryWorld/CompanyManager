create procedure fill_Persons()
  BEGIN
	DECLARE i INT;
    DECLARE dateV DATE;
	SET i = 0;
	WHILE i < 200 DO
		SET dateV = date_add(date_add(curdate(),interval - FLOOR(RAND()*(10)+22) year),interval FLOOR(RAND()*(365)) day);
		SET i = i + 1;
		INSERT INTO Persons VALUES (
        concat((SELECT DATE_FORMAT(dateV,'%y%m%d')), FLOOR(RAND()*(90000)+10000)),
        (SELECT first_name FROM sakila.actor ORDER BY RAND() LIMIT 1),
        (SELECT last_name FROM sakila.actor ORDER BY RAND() LIMIT 1),
        dateV);
	END WHILE;

END;

