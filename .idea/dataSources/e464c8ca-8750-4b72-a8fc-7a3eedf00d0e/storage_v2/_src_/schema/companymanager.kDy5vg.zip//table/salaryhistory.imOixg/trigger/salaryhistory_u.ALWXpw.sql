create trigger salaryHistory_U
  before UPDATE
  on salaryhistory
  for each row
  BEGIN
    IF new.newSalary <= 0 THEN
    set @msg = "Wrong salary";
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg;
	END IF;
END;

